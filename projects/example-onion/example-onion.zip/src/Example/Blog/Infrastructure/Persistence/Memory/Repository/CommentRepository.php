<?php

namespace Forecast\Map\Example\Blog\Infrastructure\Persistence\Memory\Repository;

use Forecast\Map\Example\Blog\Application\Services\CommentRepositoryInterface;
use Forecast\Map\Example\Blog\Domain\Model\Comment;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Normalizer\CommentNormalizer;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Relation\CommentRelation;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Seeds\CommentSeed;
use Untek\Component\Relation\Interfaces\RelationConfigInterface;
use Untek\Database\Memory\Abstract\AbstractMemoryCrudRepository;
use Untek\Persistence\Normalizer\DbNormalizerInterface;

class CommentRepository extends AbstractMemoryCrudRepository implements CommentRepositoryInterface
{

    protected array $collection = [];

    public function getClassName(): string
    {
        return Comment::class;
    }

    protected function getNormalizer(): DbNormalizerInterface
    {
        return new CommentNormalizer();
    }

    public function getRelation(): RelationConfigInterface
    {
        return new CommentRelation();
    }

    protected function getItems(): array
    {
        if (empty($this->collection)) {
            $items = (new CommentSeed())->generateItems();
            foreach ($items as $item) {
                $this->collection[] = $this->denormalize($item);
            }
        }
        return $this->collection;
    }
}