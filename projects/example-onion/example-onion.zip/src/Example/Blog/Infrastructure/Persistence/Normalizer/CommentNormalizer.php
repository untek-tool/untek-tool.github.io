<?php

namespace Forecast\Map\Example\Blog\Infrastructure\Persistence\Normalizer;

use Untek\Persistence\Normalizer\ModelNormalizer;

class CommentNormalizer extends ModelNormalizer
{

    protected function ignoreFields(): array
    {
        return [
            'post',
            'author',
        ];
    }
}