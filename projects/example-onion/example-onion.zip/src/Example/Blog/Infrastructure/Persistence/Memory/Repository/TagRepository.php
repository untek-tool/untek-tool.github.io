<?php

namespace Forecast\Map\Example\Blog\Infrastructure\Persistence\Memory\Repository;

use Forecast\Map\Example\Blog\Application\Services\TagRepositoryInterface;
use Forecast\Map\Example\Blog\Domain\Model\Tag;
use Untek\Database\Memory\Abstract\AbstractMemoryCrudRepository;

class TagRepository extends AbstractMemoryCrudRepository implements TagRepositoryInterface
{

    protected array $collection = [];

    public function getClassName(): string
    {
        return Tag::class;
    }

    protected function getItems(): array
    {
        if (empty($this->collection)) {
            $this->collection = $this->generateItems();
        }
        return $this->collection;
    }

    private function generateItems(): array
    {
        $collectionSize = 500;
        $collection = [];
        for ($id = 1; $id <= $collectionSize; $id++) {
            $tag = new Tag();
            $tag->setId($id);
            $tag->setTitle('Tag ' . $id);
            $collection[] = $tag;
        }
        return $collection;
    }
}