<?php

namespace Forecast\Map\Example\Blog\Infrastructure\Persistence\Seeds;

use DateTime;

class PostSeed
{

    public function generateItems(): array
    {
        $collectionSize = 10;
        $collection = [];
        for ($id = 1; $id <= $collectionSize; $id++) {
            $item = [
                'id' => $id,
                'title' => 'Post ' . $id,
                'content' => 'Content ' . $id,
                'author_id' => $id,
                'status_id' => $id,
                'created_at' => (new DateTime())->format(DateTime::ISO8601),
            ];
            $collection[] = $item;
        }
        return $collection;
    }
}