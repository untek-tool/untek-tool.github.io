<?php

namespace Forecast\Map\Example\Blog\Infrastructure\Persistence\Relation;

use Forecast\Map\Example\Blog\Application\Services\CommentRepositoryInterface;
use Untek\Component\Relation\Interfaces\RelationConfigInterface;
use Untek\Component\Relation\Libs\RelationConfigurator;
use Untek\Component\Relation\Libs\Types\OneToManyRelation;
use Untek\Component\Relation\Libs\Types\OneToOneRelation;
use Untek\User\Authentication\Domain\Interfaces\Repositories\IdentityRepositoryInterface;

class PostRelation implements RelationConfigInterface
{

    public function relations(RelationConfigurator $configurator): void
    {
        $configurator->add(
            new OneToOneRelation(
                'author_id',
                'author',
                IdentityRepositoryInterface::class,
                'id'
            )
        );
        $configurator->add(
            new OneToManyRelation(
                'id',
                'comments',
                CommentRepositoryInterface::class,
                'post_id',
            )
        );
    }
}