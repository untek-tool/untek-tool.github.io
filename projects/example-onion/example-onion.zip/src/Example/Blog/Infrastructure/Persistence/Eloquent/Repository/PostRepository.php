<?php

namespace Forecast\Map\Example\Blog\Infrastructure\Persistence\Eloquent\Repository;

use Forecast\Map\Example\Blog\Application\Services\PostRepositoryInterface;
use Forecast\Map\Example\Blog\Domain\Model\Post;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Normalizer\PostNormalizer;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Relation\PostRelation;
use Untek\Component\Relation\Interfaces\RelationConfigInterface;
use Untek\Database\Eloquent\Infrastructure\Abstract\AbstractEloquentCrudRepository;
use Untek\Persistence\Normalizer\DbNormalizerInterface;

//#[AsEntityRepository]
class PostRepository extends AbstractEloquentCrudRepository implements PostRepositoryInterface
{

    public function getTableName(): string
    {
        return 'blog_post';
    }

    public function getClassName(): string
    {
        return Post::class;
    }

    protected function getNormalizer(): DbNormalizerInterface
    {
        return new PostNormalizer();
    }

    public function getRelation(): RelationConfigInterface
    {
        return new PostRelation();
    }
}