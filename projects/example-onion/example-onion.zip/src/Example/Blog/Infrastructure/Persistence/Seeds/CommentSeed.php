<?php

namespace Forecast\Map\Example\Blog\Infrastructure\Persistence\Seeds;

use DateTime;

class CommentSeed
{

    public function generateItems(): array
    {
        $collectionSize = 10;
        $collection = [];
        for ($id = 1; $id <= $collectionSize; $id++) {
            $item = [
                'id' => $id,
                'content' => 'Comment ' . $id,
                'post_id' => $id,
                'author_id' => $id,
                'status_id' => 100,
                'created_at' => (new DateTime())->format(DateTime::ISO8601),
            ];
            $collection[] = $item;
        }
        return $collection;
    }
}