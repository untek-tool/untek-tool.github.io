<?php

namespace Forecast\Map\Example\Blog\Infrastructure\Persistence\Eloquent\Repository;

use Forecast\Map\Example\Blog\Application\Services\CommentRepositoryInterface;
use Forecast\Map\Example\Blog\Domain\Model\Comment;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Normalizer\CommentNormalizer;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Relation\CommentRelation;
use Untek\Component\Relation\Interfaces\RelationConfigInterface;
use Untek\Database\Eloquent\Infrastructure\Abstract\AbstractEloquentCrudRepository;
use Untek\Persistence\Normalizer\DbNormalizerInterface;

class CommentRepository extends AbstractEloquentCrudRepository implements CommentRepositoryInterface
{

    public function getTableName(): string
    {
        return 'blog_comment';
    }

    public function getClassName(): string
    {
        return Comment::class;
    }

    protected function getNormalizer(): DbNormalizerInterface
    {
        return new CommentNormalizer();
    }

    public function getRelation(): RelationConfigInterface
    {
        return new CommentRelation();
    }
}