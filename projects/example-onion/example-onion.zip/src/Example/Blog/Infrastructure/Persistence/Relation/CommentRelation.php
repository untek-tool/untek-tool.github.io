<?php

namespace Forecast\Map\Example\Blog\Infrastructure\Persistence\Relation;

use Untek\Component\Relation\Interfaces\RelationConfigInterface;
use Untek\Component\Relation\Libs\RelationConfigurator;
use Untek\Component\Relation\Libs\Types\OneToOneRelation;
use Untek\User\Authentication\Domain\Interfaces\Repositories\IdentityRepositoryInterface;

class CommentRelation implements RelationConfigInterface
{

    public function relations(RelationConfigurator $configurator): void
    {
        $configurator->add(
            new OneToOneRelation(
                'author_id',
                'author',
                IdentityRepositoryInterface::class,
                'id'
            )
        );
    }
}