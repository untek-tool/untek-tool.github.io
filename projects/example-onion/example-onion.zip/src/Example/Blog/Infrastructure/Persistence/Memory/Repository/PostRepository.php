<?php

namespace Forecast\Map\Example\Blog\Infrastructure\Persistence\Memory\Repository;

use Forecast\Map\Example\Blog\Application\Services\PostRepositoryInterface;
use Forecast\Map\Example\Blog\Domain\Model\Post;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Normalizer\PostNormalizer;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Relation\PostRelation;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Seeds\PostSeed;
use Untek\Component\Relation\Interfaces\RelationConfigInterface;
use Untek\Database\Memory\Abstract\AbstractMemoryCrudRepository;
use Untek\Persistence\Normalizer\DbNormalizerInterface;

class PostRepository extends AbstractMemoryCrudRepository implements PostRepositoryInterface
{

    protected array $collection = [];

    public function getClassName(): string
    {
        return Post::class;
    }

    protected function getNormalizer(): DbNormalizerInterface
    {
        return new PostNormalizer();
    }

    public function getRelation(): RelationConfigInterface
    {
        return new PostRelation();
    }

    protected function getItems(): array
    {
        if (empty($this->collection)) {
            $items = (new PostSeed())->generateItems();
            foreach ($items as $item) {
                $this->collection[] = $this->denormalize($item);
            }
        }
        return $this->collection;
    }
}