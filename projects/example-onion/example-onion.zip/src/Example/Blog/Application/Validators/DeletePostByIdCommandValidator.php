<?php

namespace Forecast\Map\Example\Blog\Application\Validators;

use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\Constraints\Collection;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Positive;
use Untek\Model\Validator\Libs\AbstractObjectValidator;

class DeletePostByIdCommandValidator extends AbstractObjectValidator
{

    public function getConstraint(): Constraint
    {
        return new Collection([
            'fields' => [
                'id' => [
                    new NotBlank(),
                    new Positive(),
                ],
            ]
        ]);
    }
}