<?php

namespace Forecast\Map\Example\Blog\Application\Validators;

use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\Constraints\Collection;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\Positive;
use Untek\Model\Pagination\Constrains\ExpandConstraint;
use Untek\Model\Pagination\Constrains\FilterConstraint;
use Untek\Model\Pagination\Constrains\SortConstraint;
use Untek\Model\Pagination\Factories\PageConstraintFactory;
use Untek\Model\Validator\Libs\AbstractObjectValidator;

class GetPostListQueryValidator extends AbstractObjectValidator
{

    public function getConstraint(): Constraint
    {
        return new Collection([
            'fields' => [
                'filter' => new FilterConstraint([
                    'id' => [
                        new Positive(),
                    ],
                    'title' => [
                        new Length(null, 3, 255),
                    ],
                    'content' => [
                        new Length(null, 3),
                    ],
                ]),
                'sort' => new SortConstraint(['id', 'title', 'content']),
                'expand' => new ExpandConstraint(['comments', 'comments.author', 'author']),
                'page' => PageConstraintFactory::getConstraint(20),
            ]
        ], null, null, null, true);
    }
}