<?php

namespace Forecast\Map\Example\Blog\Application\Validators;

use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\Constraints\Collection;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Positive;
use Untek\Model\Validator\Libs\AbstractObjectValidator;

class CreatePostCommandValidator extends AbstractObjectValidator
{

    public function getConstraint(): Constraint
    {
        return new Collection([
            'fields' => [
                'title' => [
                    new NotBlank(),
                    new Length(null, 3, 255),
                ],
                'content' => [
                    new NotBlank(),
                    new Length(null, 3),
                ],
                'authorId' => [
                    new NotBlank(),
                    new Positive(),
                ],
            ]
        ]);
    }
}