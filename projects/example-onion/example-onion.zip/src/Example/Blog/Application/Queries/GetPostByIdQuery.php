<?php

namespace Forecast\Map\Example\Blog\Application\Queries;

use Symfony\Component\Validator\Constraints as Assert;
use Untek\Model\DataProvider\Interfaces\ExpandQueryInterface;

class GetPostByIdQuery implements ExpandQueryInterface
{

    #[Assert\Positive()]
    private int $id;
    private array $expand = [];

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }

    public function getExpand(): array
    {
        return $this->expand;
    }

    public function setExpand(array $expand): void
    {
        $this->expand = $expand;
    }
}