<?php

namespace Forecast\Map\Example\Blog\Application\Services;

use Untek\Persistence\Contract\Interfaces\RepositoryCrudInterface;

interface CommentRepositoryInterface extends RepositoryCrudInterface
{

}