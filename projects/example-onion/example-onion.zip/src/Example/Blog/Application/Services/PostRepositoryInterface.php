<?php

namespace Forecast\Map\Example\Blog\Application\Services;

use Untek\Persistence\Contract\Interfaces\RepositoryCrudInterface;

interface PostRepositoryInterface extends RepositoryCrudInterface
{

}