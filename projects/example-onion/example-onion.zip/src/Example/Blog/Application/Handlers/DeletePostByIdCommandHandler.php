<?php

namespace Forecast\Map\Example\Blog\Application\Handlers;

use Forecast\Map\Example\Blog\Application\Commands\DeletePostByIdCommand;
use Forecast\Map\Example\Blog\Application\Services\PostRepositoryInterface;
use Forecast\Map\Example\Blog\Application\Validators\DeletePostByIdCommandValidator;
use Symfony\Contracts\Translation\TranslatorInterface;
use Untek\Component\Cqrs\Application\Abstract\CqrsHandlerInterface;
use Untek\Model\Validator\Exceptions\UnprocessableEntityException;
use Untek\Persistence\Contract\Exceptions\NotFoundException;

class DeletePostByIdCommandHandler implements CqrsHandlerInterface
{

    public function __construct(
        private TranslatorInterface $translator,
        private PostRepositoryInterface $repository,
        private DeletePostByIdCommandValidator $commandValidator,
    )
    {
    }

    /**
     * @param DeletePostByIdCommand $query
     * @throws UnprocessableEntityException
     * @throws NotFoundException
     */
    public function __invoke(DeletePostByIdCommand $query): void
    {
//        $validator = new DeletePostByIdCommandValidator($this->translator);
        $this->commandValidator->validate($query);

        $entity = $this->repository->findOneById($query->getId());
        $this->repository->deleteById($entity->getId());
    }
}