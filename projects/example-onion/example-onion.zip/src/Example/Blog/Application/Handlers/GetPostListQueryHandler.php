<?php

namespace Forecast\Map\Example\Blog\Application\Handlers;

use Forecast\Map\Example\Blog\Application\Queries\GetPostListQuery;
use Forecast\Map\Example\Blog\Application\Services\PostRepositoryInterface;
use Forecast\Map\Example\Blog\Application\Validators\GetPostListQueryValidator;
use Symfony\Contracts\Translation\TranslatorInterface;
use Untek\Component\Cqrs\Application\Abstract\CqrsHandlerInterface;
use Untek\Model\DataProvider\DataProvider;
use Untek\Model\DataProvider\Dto\CollectionData;
use Untek\Model\Validator\Exceptions\UnprocessableEntityException;

class GetPostListQueryHandler implements CqrsHandlerInterface
{

    public function __construct(
        private TranslatorInterface $translator,
        private PostRepositoryInterface $repository,
        private GetPostListQueryValidator $commandValidator,
    )
    {
    }

    /**
     * @param GetPostListQuery $query
     * @return CollectionData
     * @throws UnprocessableEntityException
     */
    public function __invoke(GetPostListQuery $query): CollectionData
    {
//        $validator = new GetPostListQueryValidator($this->translator);
        $this->commandValidator->validate($query);
        return $this->findAll($query);
    }

    /**
     * @param object $query
     * @return CollectionData
     * @throws UnprocessableEntityException
     */
    protected function findAll(object $query): CollectionData
    {
        $dataProvider = new DataProvider($this->repository);
        return $dataProvider->findAll($query);
    }
}