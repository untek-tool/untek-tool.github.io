<?php

namespace Forecast\Map\Example\Blog\Application\Handlers;

use Forecast\Map\Example\Blog\Application\Commands\UpdatePostByIdCommand;
use Forecast\Map\Example\Blog\Application\Services\PostRepositoryInterface;
use Forecast\Map\Example\Blog\Application\Validators\UpdatePostByIdCommandValidator;
use Symfony\Contracts\Translation\TranslatorInterface;
use Untek\Component\Cqrs\Application\Abstract\CqrsHandlerInterface;
use Untek\Core\Instance\Helpers\PropertyHelper;
use Untek\Model\EntityManager\Interfaces\EntityManagerInterface;
use Untek\Model\Validator\Exceptions\UnprocessableEntityException;
use Untek\Persistence\Contract\Exceptions\NotFoundException;

class UpdatePostByIdCommandHandler implements CqrsHandlerInterface
{

    public function __construct(
        private TranslatorInterface $translator,
        private EntityManagerInterface $em,
        private PostRepositoryInterface $repository,
        private UpdatePostByIdCommandValidator $commandValidator,
    )
    {
    }

    /**
     * @param UpdatePostByIdCommand $command
     * @throws UnprocessableEntityException
     * @throws NotFoundException
     */
    public function __invoke(UpdatePostByIdCommand $command): void
    {
//        $validator = new UpdatePostByIdCommandValidator($this->translator);
        $this->commandValidator->validate($command);

        $entity = $this->repository->findOneById($command->getId());
        PropertyHelper::mergeObjects($command, $entity);
        $this->em->update($entity);
//        $this->repository->update($entity);
    }
}