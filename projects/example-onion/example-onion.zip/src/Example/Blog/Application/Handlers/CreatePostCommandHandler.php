<?php

namespace Forecast\Map\Example\Blog\Application\Handlers;

use Forecast\Map\Example\Blog\Application\Commands\CreatePostCommand;
use Forecast\Map\Example\Blog\Application\Services\PostRepositoryInterface;
use Forecast\Map\Example\Blog\Application\Validators\CreatePostCommandValidator;
use Forecast\Map\Example\Blog\Domain\Model\Post;
use Symfony\Contracts\Translation\TranslatorInterface;
use Untek\Component\Cqrs\Application\Abstract\CqrsHandlerInterface;
use Untek\Core\Instance\Helpers\PropertyHelper;
use Untek\Model\EntityManager\Interfaces\EntityManagerInterface;
use Untek\Model\Validator\Exceptions\UnprocessableEntityException;

class CreatePostCommandHandler implements CqrsHandlerInterface
{

    public function __construct(
        private TranslatorInterface $translator,
        private EntityManagerInterface $em,
        private PostRepositoryInterface $repository,
        private CreatePostCommandValidator $commandValidator,
    )
    {
    }

    /**
     * @param CreatePostCommand $command
     * @return Post
     * @throws UnprocessableEntityException
     */
    public function __invoke(CreatePostCommand $command): Post
    {
//        $validator = new CreatePostCommandValidator($this->translator);
        $this->commandValidator->validate($command);

        $entity = new Post();
        PropertyHelper::mergeObjects($command, $entity);
//        $this->repository->create($entity);
        $this->em->insert($entity);
        return $entity;
    }
}