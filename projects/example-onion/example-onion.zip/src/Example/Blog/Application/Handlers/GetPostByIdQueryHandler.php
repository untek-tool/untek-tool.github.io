<?php

namespace Forecast\Map\Example\Blog\Application\Handlers;

use Forecast\Map\Example\Blog\Application\Queries\GetPostByIdQuery;
use Forecast\Map\Example\Blog\Application\Services\PostRepositoryInterface;
use Forecast\Map\Example\Blog\Application\Validators\GetPostByIdQueryValidator;
use Symfony\Contracts\Translation\TranslatorInterface;
use Untek\Component\Cqrs\Application\Abstract\CqrsHandlerInterface;
use Untek\Model\Validator\Exceptions\UnprocessableEntityException;
use Untek\Persistence\Contract\Exceptions\NotFoundException;

class GetPostByIdQueryHandler implements CqrsHandlerInterface
{

    public function __construct(
        private TranslatorInterface $translator,
        private PostRepositoryInterface $repository,
        private GetPostByIdQueryValidator $commandValidator,
    )
    {
    }

    /**
     * @param GetPostByIdQuery $query
     * @return object
     * @throws UnprocessableEntityException
     * @throws NotFoundException
     */
    public function __invoke(GetPostByIdQuery $query): object
    {
//        $validator = new GetPostByIdQueryValidator($this->translator);
        $this->commandValidator->validate($query);

        return $this->repository->findOneById($query->getId(), $query->getExpand());
    }
}