<?php

namespace Forecast\Map\Example\Blog\Application\Commands;

use Symfony\Component\Validator\Constraints as Assert;

class DeletePostByIdCommand
{

    #[Assert\Positive()]
    private int $id;

    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }
}