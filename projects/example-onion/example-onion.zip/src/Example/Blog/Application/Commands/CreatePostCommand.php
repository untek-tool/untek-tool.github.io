<?php

namespace Forecast\Map\Example\Blog\Application\Commands;

use Symfony\Component\Validator\Constraints as Assert;

class CreatePostCommand
{

    #[Assert\Length(min: 3, max: 255)]
    private string $title;

    #[Assert\Length(min: 3)]
    private string $content;

    #[Assert\Positive()]
    private int $authorId;

    public function getTitle(): string
    {
        return $this->title;
    }

    public function setTitle(string $title): void
    {
        $this->title = $title;
    }

    public function getContent(): string
    {
        return $this->content;
    }

    public function setContent(string $content): void
    {
        $this->content = $content;
    }

    public function getAuthorId(): int
    {
        return $this->authorId;
    }

    public function setAuthorId(int $authorId): void
    {
        $this->authorId = $authorId;
    }

}