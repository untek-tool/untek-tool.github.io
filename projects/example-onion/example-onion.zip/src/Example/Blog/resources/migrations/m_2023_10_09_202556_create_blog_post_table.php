<?php

namespace Migrations;

use Illuminate\Database\Schema\Blueprint;
use Untek\Database\Migration\Infrastructure\Migration\Abstract\BaseCreateTableMigration;

class m_2023_10_09_202556_create_blog_post_table extends BaseCreateTableMigration
{

    protected $tableName = 'blog_post';
    protected $tableComment = 'Посты блога';

    public function tableStructure(Blueprint $table): void
    {
        $table->integer('id')->autoIncrement()->comment('Идентификатор');
        $table->string('title')->comment('Название');
        $table->text('content')->comment('Контент');
    }
}
