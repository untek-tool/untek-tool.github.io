<?php

namespace Migrations;

use Illuminate\Database\Schema\Blueprint;
use Untek\Database\Migration\Infrastructure\Migration\Abstract\BaseColumnMigration;

class m_2023_12_17_201412_add_column_in_blog_post_table extends BaseColumnMigration
{

    protected $tableName = 'blog_post';

    public function tableStructure(Blueprint $table): void
    {
        $table->integer('author_id')->comment('Автор');

        $this->addForeign($table, 'author_id', 'user_identity');
    }
}
