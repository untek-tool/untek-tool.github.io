<?php

namespace Migrations;

use Illuminate\Database\Schema\Blueprint;
use Untek\Database\Migration\Infrastructure\Migration\Abstract\BaseCreateTableMigration;

class m_2023_12_17_202556_create_blog_comment_table extends BaseCreateTableMigration
{

    protected $tableName = 'blog_comment';
    protected $tableComment = 'Комментарии постов блога';

    public function tableStructure(Blueprint $table): void
    {
        $table->integer('id')->autoIncrement()->comment('Идентификатор');
        $table->integer('post_id')->comment('Пост');
        $table->text('content')->comment('Контент');
        $table->integer('status_id')->comment('Статус');
        $table->integer('author_id')->comment('Автор');
        $table->dateTime('created_at')->comment('Время создания');
        $table->dateTime('updated_at')->nullable()->comment('Время обновления');

        $this->addForeign($table, 'author_id', 'user_identity');
        $this->addForeign($table, 'post_id', 'blog_post');
    }
}
