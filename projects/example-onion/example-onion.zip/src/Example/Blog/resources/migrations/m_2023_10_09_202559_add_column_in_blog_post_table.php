<?php

namespace Migrations;

use Illuminate\Database\Schema\Blueprint;
use Untek\Database\Migration\Infrastructure\Migration\Abstract\BaseColumnMigration;

class m_2023_10_09_202559_add_column_in_blog_post_table extends BaseColumnMigration
{

    protected $tableName = 'blog_post';

    public function tableStructure(Blueprint $table): void
    {
        $table->integer('status_id')->comment('Статус');
        $table->dateTime('created_at')->comment('Время создания');
        $table->dateTime('updated_at')->nullable()->comment('Время обновления');
    }
}
