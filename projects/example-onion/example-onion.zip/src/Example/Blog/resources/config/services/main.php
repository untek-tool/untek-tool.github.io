<?php

use Forecast\Map\Example\Blog\Application\Services\CommentRepositoryInterface;
use Forecast\Map\Example\Blog\Application\Services\PostRepositoryInterface;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Eloquent\Repository\CommentRepository as EloquentCommentRepository;
use Forecast\Map\Example\Blog\Infrastructure\Persistence\Eloquent\Repository\PostRepository as EloquentPostRepository;
use Illuminate\Database\Capsule\Manager;
use Symfony\Component\DependencyInjection\Loader\Configurator\ContainerConfigurator;
use function Symfony\Component\DependencyInjection\Loader\Configurator\service;

return static function (ContainerConfigurator $configurator): void {
    $services = $configurator->services()->defaults()->public()->autowire()->autoconfigure();

    $services
        ->load('Forecast\Map\Example\Blog\\', __DIR__ . '/../../..')
        ->exclude([
            __DIR__ . '/../../../{resources,Domain,Application/Commands,Application/Queries}',
            __DIR__ . '/../../../**/*{Event.php,Helper.php,Message.php,Task.php,Relation.php,Normalizer.php}',
            __DIR__ . '/../../../**/{Dto,Enums}',
        ]);

    $services->set(EloquentPostRepository::class)
        ->args([
            service(Manager::class),
        ])
        ->tag('repository');

    $services->alias(PostRepositoryInterface::class, EloquentPostRepository::class);

    $services->alias(CommentRepositoryInterface::class, EloquentCommentRepository::class);
};