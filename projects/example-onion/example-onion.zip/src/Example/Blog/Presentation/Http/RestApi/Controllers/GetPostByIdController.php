<?php

namespace Forecast\Map\Example\Blog\Presentation\Http\RestApi\Controllers;

use Forecast\Map\Example\Blog\Application\Queries\GetPostByIdQuery;
use Forecast\Map\Example\Blog\Presentation\Http\RestApi\Schemas\PostRestApiSchema;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Untek\Component\Cqrs\Application\Services\CommandBusInterface;
use Untek\Framework\RestApi\Presentation\Http\Symfony\Controllers\AbstractRestApiController;
use Untek\Framework\RestApi\Presentation\Http\Symfony\Helpers\QueryParameterHelper;

#[Route('/post/{id}', methods: ['GET'], name: 'blog/post/get-one')]
class GetPostByIdController extends AbstractRestApiController
{

    public function __construct(
        private CommandBusInterface $bus,
        protected PostRestApiSchema $schema,
    )
    {
    }

    public function __invoke(int $id, Request $request): JsonResponse
    {
        $query = new GetPostByIdQuery();
        $query->setId($id);
        QueryParameterHelper::fillQueryFromRequest($request, $query);

        $entity = $this->bus->handle($query);
        $data = $this->encodeObject($entity);
        return $this->serialize($data);
    }
}
