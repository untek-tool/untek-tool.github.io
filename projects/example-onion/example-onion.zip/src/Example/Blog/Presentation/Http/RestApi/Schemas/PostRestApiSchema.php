<?php

namespace Forecast\Map\Example\Blog\Presentation\Http\RestApi\Schemas;

use Forecast\Map\Example\Blog\Domain\Model\Post;
use Symfony\Component\Security\Core\User\UserInterface;
use Untek\Framework\RestApi\Presentation\Http\Symfony\Interfaces\RestApiSchemaInterface;

class PostRestApiSchema implements RestApiSchemaInterface
{

    public function encode(mixed $data): mixed
    {
        /** @var Post $data */

        $item = [
            'id' => $data->getId(),
            'title' => $data->getTitle(),
            'content' => $data->getContent(),
            'statusId' => $data->getStatusId(),
            'author' => $this->encodeAuthor($data->getAuthor()),
//            'authorId' => $data->getAuthorId(),
        ];

        if($data->getComments()) {
            $comments = [];
            foreach ($data->getComments() as $comment) {
                $comments[] = [
                    'id' => $comment->getId(),
                    'content' => $comment->getContent(),
                    'statusId' => $comment->getStatusId(),
                    'author' => $this->encodeAuthor($comment->getAuthor()),
                ];
            }
            $item['comments'] = $comments;
        }

        return $item;
    }

    private function encodeAuthor(?UserInterface $user): ?array
    {
        if(empty($user)) {
            return null;
        }
        return [
            'id' => $user->getId(),
            'username' => $user->getUsername(),
        ];
    }
}