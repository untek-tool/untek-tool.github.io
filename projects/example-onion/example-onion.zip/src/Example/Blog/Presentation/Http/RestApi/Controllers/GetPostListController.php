<?php

namespace Forecast\Map\Example\Blog\Presentation\Http\RestApi\Controllers;

use Forecast\Map\Example\Blog\Application\Queries\GetPostListQuery;
use Forecast\Map\Example\Blog\Presentation\Http\RestApi\Schemas\PostRestApiSchema;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Untek\Component\Cqrs\Application\Services\CommandBusInterface;
use Untek\Framework\RestApi\Presentation\Http\Symfony\Controllers\AbstractGetListRestApiController;
use Untek\Framework\RestApi\Presentation\Http\Symfony\Helpers\QueryParameterHelper;

#[Route('/post', methods: ['GET'], name: 'blog/post/get-list')]
class GetPostListController extends AbstractGetListRestApiController
{

    public function __construct(
        private CommandBusInterface $bus,
        protected PostRestApiSchema $schema,
    )
    {
    }

    public function __invoke(Request $request): JsonResponse
    {
        $query = new GetPostListQuery();
        QueryParameterHelper::fillQueryFromRequest($request, $query);
        $collectionData = $this->bus->handle($query);
        return $this->createResponse($collectionData);
    }
}
