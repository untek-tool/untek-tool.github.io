<?php

namespace Forecast\Map\Example\Blog\Presentation\Http\RestApi\Controllers;

use Forecast\Map\Example\Blog\Application\Commands\CreatePostCommand;
use Forecast\Map\Example\Blog\Presentation\Http\RestApi\Schemas\PostRestApiSchema;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Untek\Component\Cqrs\Application\Services\CommandBusInterface;
use Untek\Core\App\Services\ControllerAccessChecker;
use Untek\Framework\RestApi\Presentation\Http\Symfony\Controllers\AbstractCreateRestApiController;

#[Route('/post', methods: ['POST'], name: 'blog/post/create')]
class CreatePostController extends AbstractCreateRestApiController
{

    protected string $routeName = 'blog/post/get-one';

    public function __construct(
        private CommandBusInterface $bus,
        protected UrlGeneratorInterface $urlGenerator,
        private ControllerAccessChecker $accessChecker,
        protected PostRestApiSchema $schema,
//        protected ObjectValidator $objectValidator,
    )
    {
    }

    public function __invoke(Request $request): JsonResponse
    {
        /** @var int $userId текущий аутентифицированный пользователь */
        $userId = $this->accessChecker->getUser()->getId();
        /** @var CreatePostCommand $command */

//        $data = $this->extractData($request);
//        $data['authorId'] = $userId;
//        $command = $this->createObject($data, CreatePostCommand::class);

        $command = $this->createForm($request, CreatePostCommand::class);
        $command->setAuthorId($userId);
        $entity = $this->bus->handle($command);
        return $this->createResponse($entity);
    }
}
