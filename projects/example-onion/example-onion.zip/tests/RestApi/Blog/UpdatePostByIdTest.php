<?php

namespace Tests\RestApi\Blog;

use Tests\RestApi\Abstract\AbstractRestApiTestCase;
use Untek\Framework\RestApiTest\Asserts\RestApiResponseAssert;

class UpdatePostByIdTest extends AbstractRestApiTestCase
{

    protected function fixtures(): array
    {
        return [
            'user_credential',
            'user_token',
            'user_assigned_roles',
            'blog_post',
            'blog_comment',
        ];
    }

    public function testUpdatePost()
    {
        $data = [
            'title' => 'Title Post 1',
            'content' => 'Content for post 1',
        ];
        $this->authByLogin('admin');
        $response = $this->sendRequest('/v1/post/1', 'PATCH', $data);

        (new RestApiResponseAssert($response))
            ->assertStatus(204);

        $response = $this->sendRequest('/v1/post/1');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, 'id')
            ->assertPath('Title Post 1', 'title')
            ->assertPath('Content for post 1', 'content');
    }

    public function testUpdatePostWithSmallTitle()
    {
        $data = [
            'title' => 'Po',
            'content' => 'Co',
        ];
        $this->authByLogin('admin');
        $response = $this->sendRequest('/v1/post/1', 'PATCH', $data);

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'title',
                    'message' => 'Значение слишком короткое. Должно быть равно 3 символам или больше.',
                ],
                [
                    'field' => 'content',
                    'message' => 'Значение слишком короткое. Должно быть равно 3 символам или больше.',
                ],

            ], 'errors');
    }

    public function testUpdatePostEmptyBody()
    {
        $data = [];
        $this->authByLogin('admin');
        $response = $this->sendRequest('/v1/post/1', 'PATCH', $data);

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'title',
                    'message' => 'Это поле отсутствует.',
                ],
                [
                    'field' => 'content',
                    'message' => 'Это поле отсутствует.',
                ],
            ], 'errors');

        $data = [
            'title' => '',
            'content' => '',
        ];
        $response = $this->sendRequest('/v1/post/1', 'PATCH', $data);

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'title',
                    'message' => 'Значение не должно быть пустым.',
                ],
                [
                    'field' => 'title',
                    'message' => 'Значение слишком короткое. Должно быть равно 3 символам или больше.',
                ],
                [
                    'field' => 'content',
                    'message' => 'Значение не должно быть пустым.',
                ],
                [
                    'field' => 'content',
                    'message' => 'Значение слишком короткое. Должно быть равно 3 символам или больше.',
                ],
            ], 'errors');
    }

    public function testUpdatePostInputError()
    {
        $data = [
            'content' => 'Content for post 1',
        ];
        $this->authByLogin('admin');
        $response = $this->sendRequest('/v1/post/1', 'PATCH', $data);

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'title',
                    'message' => 'Это поле отсутствует.',
                ],
            ], 'errors');
    }

    public function testUpdateNotFoundPost()
    {
        $data = [
            'title' => 'Post 1',
            'content' => 'Content for post 1',
        ];
        $this->authByLogin('admin');
        $response = $this->sendRequest('/v1/post/101', 'PATCH', $data);

        (new RestApiResponseAssert($response))
            ->assertStatus(404);
    }
}
