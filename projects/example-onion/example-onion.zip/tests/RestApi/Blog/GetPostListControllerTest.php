<?php

namespace Tests\RestApi\Blog;

use Tests\RestApi\Abstract\AbstractRestApiTest;

class GetPostListControllerTest extends AbstractRestApiTest
{

    /**
     * @see php bin/phpunit --filter testSuccess tests/RestApi/Blog/GetPostListControllerTest.php
     */
    public function testSuccess(): void
    {
        $client = static::createClient();
        $client->jsonRequest('GET', '/rest-api/v1/post');
        $this->assertResponseIsSuccessful();

        $responseData = $this->extractDataFromJson($client);
        $this->assertCount(10, $responseData);
    }
}
