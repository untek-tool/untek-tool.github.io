<?php

namespace Tests\RestApi\Blog;

use Tests\RestApi\Abstract\AbstractRestApiTestCase;
use Untek\Framework\RestApiTest\Asserts\RestApiResponseAssert;

class GetPostByIdTest extends AbstractRestApiTestCase
{

    protected function fixtures(): array
    {
        return [
            'user_credential',
            'user_token',
            'user_assigned_roles',
            'blog_post',
            'blog_comment',
        ];
    }

    public function testGetPost()
    {
        $response = $this->sendRequest('/v1/post/1');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, 'id')
            ->assertPath('Post 1', 'title')
            ->assertPath('Content 1', 'content');
    }

    public function testGetPostWithRelationsValidation()
    {
        $response = $this->sendRequest('/v1/post/1?expand=author,comments.author1');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'expand',
                    'message' => 'Одно или несколько заданных значений недопустимо.',
                ],
            ], 'errors');

        $response = $this->sendRequest('/v1/post/1?expand=author1,comments.author');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'expand',
                    'message' => 'Одно или несколько заданных значений недопустимо.',
                ],
            ], 'errors');
    }

    public function testGetPostWithRelations()
    {
        $response = $this->sendRequest('/v1/post/1?expand=author,comments.author');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, 'id')
            ->assertPath('Post 1', 'title')
            ->assertPath('Content 1', 'content')

            ->assertPath(1, 'author.id')

            ->assertPath('1', 'comments.0.id')
            ->assertPath('Comment 1', 'comments.0.content')
            ->assertPath('1', 'comments.0.author.id')
        ;

        $response = $this->sendRequest('/v1/post/1?expand[]=comments.author&expand[]=author');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, 'id')
            ->assertPath('Post 1', 'title')
            ->assertPath('Content 1', 'content')

            ->assertPath(1, 'author.id')

            ->assertPath('1', 'comments.0.id')
            ->assertPath('Comment 1', 'comments.0.content')
            ->assertPath('1', 'comments.0.author.id')
        ;

        $response = $this->sendRequest('/v1/post/1?expand=author,comments');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, 'id')
            ->assertPath('Post 1', 'title')
            ->assertPath('Content 1', 'content')

            ->assertPath(1, 'author.id')

            ->assertPath('1', 'comments.0.id')
            ->assertPath('Comment 1', 'comments.0.content')
            ->assertPath(null, 'comments.0.author')
        ;

        $response = $this->sendRequest('/v1/post/1?expand=author');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, 'id')
            ->assertPath('Post 1', 'title')
            ->assertPath('Content 1', 'content')

            ->assertPath(1, 'author.id')

            ->assertPath(null, 'comments')
        ;

        $response = $this->sendRequest('/v1/post/1');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, 'id')
            ->assertPath('Post 1', 'title')
            ->assertPath('Content 1', 'content')

            ->assertPath(null, 'author')

            ->assertPath(null, 'comments')
        ;
    }

    public function testGetPostNotFound()
    {
        $response = $this->sendRequest('/v1/post/101');

        (new RestApiResponseAssert($response))
            ->assertStatus(404);
    }

    public function testGetPostWithBadId()
    {
        $response = $this->sendRequest('/v1/post/-1');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'id',
                    'message' => 'Значение должно быть положительным.',
                ],
            ], 'errors');

        $response = $this->sendRequest('/v1/post/0');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'id',
                    'message' => 'Значение должно быть положительным.',
                ],
            ], 'errors');
    }
}
