<?php

namespace Tests\RestApi\Blog;

use Tests\RestApi\Abstract\AbstractRestApiTestCase;
use Untek\Framework\RestApiTest\Asserts\RestApiResponseAssert;

class CreatePostTest extends AbstractRestApiTestCase
{

    protected function fixtures(): array
    {
        return [
            'user_credential',
            'user_token',
            'user_assigned_roles',
            'blog_post',
            'blog_comment',
        ];
    }

    /**
     * @see php bin/phpunit --filter testCreatePost tests/RestApi/Blog/CreatePostTest.php
     */
    public function testCreatePost()
    {
        $data = [
            'title' => 'Post 1',
            'content' => 'Content for post 1',
        ];

        $this->authByLogin('admin');
        $response = $this->sendRequest('/v1/post', 'POST', $data);

        (new RestApiResponseAssert($response))
            ->assertStatus(201)
            ->assertPath(11, 'id')
            ->assertPath('Post 1', 'title')
            ->assertPath('Content for post 1', 'content')
            ->assertHeader('/rest-api/v1/post/11', 'Location');

        $this->getDatabaseAssert()
            ->assertHasRowById('blog_post', 11)
            ->assertRowById('blog_post', 11, [
                'title' => 'Post 1',
                'content' => 'Content for post 1',
            ])
            ;
    }

    public function testCreatePostEmptyBody()
    {
        $data = [];

        $this->authByLogin('admin');
        $response = $this->sendRequest('/v1/post', 'POST', $data);

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'title',
                    'message' => 'Это поле отсутствует.',
                ],
                [
                    'field' => 'content',
                    'message' => 'Это поле отсутствует.',
                ],
            ], 'errors');

        $data = [
            'title' => '',
            'content' => '',
        ];
        $response = $this->sendRequest('/v1/post', 'POST', $data);

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'title',
                    'message' => 'Значение не должно быть пустым.',
                ],
                [
                    'field' => 'title',
                    'message' => 'Значение слишком короткое. Должно быть равно 3 символам или больше.',
                ],
                [
                    'field' => 'content',
                    'message' => 'Значение не должно быть пустым.',
                ],
                [
                    'field' => 'content',
                    'message' => 'Значение слишком короткое. Должно быть равно 3 символам или больше.',
                ],
            ], 'errors');
    }

    public function testCreatePostInputError()
    {
        $data = [
            'content' => 'Content for post 1',
        ];
        $this->authByLogin('admin');
        $response = $this->sendRequest('/v1/post', 'POST', $data);

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'title',
                    'message' => 'Это поле отсутствует.',
                ],
            ], 'errors');
    }
}
