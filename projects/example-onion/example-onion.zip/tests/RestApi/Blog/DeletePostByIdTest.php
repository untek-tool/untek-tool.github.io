<?php

namespace Tests\RestApi\Blog;

use Tests\RestApi\Abstract\AbstractRestApiTestCase;
use Untek\Framework\RestApiTest\Asserts\RestApiResponseAssert;

/**
 * @see php bin/phpunit --filter tests/RestApi/Blog/DeletePostByIdTest.php
 */
class DeletePostByIdTest extends AbstractRestApiTestCase
{

    protected function fixtures(): array
    {
        return [
            'user_credential',
            'user_token',
            'user_assigned_roles',
            'blog_post',
            'blog_comment',
        ];
    }

    public function testGetPost()
    {
        $this->authByLogin('admin');
        $response = $this->sendRequest('/v1/post/1', 'DELETE');

        (new RestApiResponseAssert($response))
            ->assertStatus(204);
    }

    public function testGetPostNotFound()
    {
        $this->authByLogin('admin');
        $response = $this->sendRequest('/v1/post/101', 'DELETE');

        (new RestApiResponseAssert($response))
            ->assertStatus(404);
    }

    public function testGetPostWithBadId()
    {
        $this->authByLogin('admin');
        $response = $this->sendRequest('/v1/post/-1', 'DELETE');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'id',
                    'message' => 'Значение должно быть положительным.',
                ],
            ], 'errors');

        $response = $this->sendRequest('/v1/post/0');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'id',
                    'message' => 'Значение должно быть положительным.',
                ],
            ], 'errors');
    }
}
