<?php

namespace Tests\RestApi\Blog;

use Tests\RestApi\Abstract\AbstractRestApiTestCase;
use Untek\Framework\RestApi\Infrastructure\Enums\RestApiHeaderEnum;
use Untek\Framework\RestApiTest\Asserts\RestApiResponseAssert;

class GetPostListTest extends AbstractRestApiTestCase
{

    /**
     * @see php bin/phpunit --filter testGetPostList tests/RestApi/Blog/GetPostListTest.php
     */
    protected function fixtures(): array
    {
        return [
            'user_credential',
            'user_token',
            'user_assigned_roles',
            'blog_post',
            'blog_comment',
        ];
    }

    /**
     * @see php bin/phpunit --filter testGetPostList tests/RestApi/Blog/GetPostListTest.php
     */
    public function testGetPostList()
    {
        $response = $this->sendRequest('/v1/post?page[size]=2');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertCollectionSize(2)
            ->assertHeader(1, RestApiHeaderEnum::CURRENT_PAGE)
            ->assertHeader(2, RestApiHeaderEnum::PER_PAGE)
            ->assertHeader(10, RestApiHeaderEnum::TOTAL_COUNT)
            ->assertHeader(5, RestApiHeaderEnum::PAGE_COUNT)
            ->assertPath(1, '0.id')
            ->assertPath('Post 1', '0.title')
            ->assertPath('Content 1', '0.content')
            ->assertPath(2, '1.id')
            ->assertPath('Post 2', '1.title')
            ->assertPath('Content 2', '1.content');
    }

    /**
     * @see php bin/phpunit --filter testGetPostWithRelationsValidation tests/RestApi/Blog/GetPostListTest.php
     */
    public function testGetPostWithRelationsValidation()
    {
        $response = $this->sendRequest('/v1/post?expand=author,comments.author1');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'expand',
                    'message' => 'Одно или несколько заданных значений недопустимо.',
                ],
            ], 'errors');

        $response = $this->sendRequest('/v1/post?expand=author1,comments.author');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'expand',
                    'message' => 'Одно или несколько заданных значений недопустимо.',
                ],
            ], 'errors');
    }

    /**
     * @see php bin/phpunit --filter testGetPostListWithRelations tests/RestApi/Blog/GetPostListTest.php
     */
    public function testGetPostListWithRelations()
    {
        $response = $this->sendRequest('/v1/post?expand=author,comments.author');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, '0.id')
            ->assertPath('Post 1', '0.title')
            ->assertPath('Content 1', '0.content')
            ->assertPath(1, '0.author.id')
            ->assertPath('1', '0.comments.0.id')
            ->assertPath('Comment 1', '0.comments.0.content')
            ->assertPath('1', '0.comments.0.author.id');

        $response = $this->sendRequest('/v1/post?expand[]=comments.author&expand[]=author');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, '0.id')
            ->assertPath('Post 1', '0.title')
            ->assertPath('Content 1', '0.content')
            ->assertPath(1, '0.author.id')
            ->assertPath('1', '0.comments.0.id')
            ->assertPath('Comment 1', '0.comments.0.content')
            ->assertPath('1', '0.comments.0.author.id');

        $response = $this->sendRequest('/v1/post?expand=author,comments');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, '0.id')
            ->assertPath('Post 1', '0.title')
            ->assertPath('Content 1', '0.content')
            ->assertPath(1, '0.author.id')
            ->assertPath('1', '0.comments.0.id')
            ->assertPath('Comment 1', '0.comments.0.content')
            ->assertPath(null, '0.comments.0.author');

        $response = $this->sendRequest('/v1/post?expand=author');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, '0.id')
            ->assertPath('Post 1', '0.title')
            ->assertPath('Content 1', '0.content')
            ->assertPath(null, '0.comments');

        $response = $this->sendRequest('/v1/post');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertPath(1, '0.id')
            ->assertPath('Post 1', '0.title')
            ->assertPath('Content 1', '0.content')
            ->assertPath(null, '0.author')
            ->assertPath(null, '0.comments');
    }

    /**
     * @see php bin/phpunit --filter testGetSortedPostList tests/RestApi/Blog/GetPostListTest.php
     */
    public function testGetSortedPostList()
    {
        $response = $this->sendRequest('/v1/post?page[size]=2&sort=-title');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertCollectionSize(2)
            ->assertHeader(1, RestApiHeaderEnum::CURRENT_PAGE)
            ->assertHeader(2, RestApiHeaderEnum::PER_PAGE)
            ->assertHeader(10, RestApiHeaderEnum::TOTAL_COUNT)
            ->assertHeader(5, RestApiHeaderEnum::PAGE_COUNT)
            ->assertPath(9, '0.id')
            ->assertPath(8, '1.id');

        $response = $this->sendRequest('/v1/post?page[size]=2&sort[title]=desc');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertCollectionSize(2)
            ->assertHeader(1, RestApiHeaderEnum::CURRENT_PAGE)
            ->assertHeader(2, RestApiHeaderEnum::PER_PAGE)
            ->assertHeader(10, RestApiHeaderEnum::TOTAL_COUNT)
            ->assertHeader(5, RestApiHeaderEnum::PAGE_COUNT)
            ->assertPath(9, '0.id')
            ->assertPath(8, '1.id');

        $response = $this->sendRequest('/v1/post?page[size]=2&sort[id]=asc&sort[titleBad]=desc');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'sort.titleBad',
                    'message' => 'Это поле не ожидалось.',
                ],
            ], 'errors');
    }

    /**
     * @see php bin/phpunit --filter testGetFilteredPostList tests/RestApi/Blog/GetPostListTest.php
     */
    public function testGetFilteredPostList()
    {
        $response = $this->sendRequest('/v1/post?filter[content]=Content 2');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertCollectionSize(1)
            ->assertHeader(1, RestApiHeaderEnum::CURRENT_PAGE)
            ->assertHeader(10, RestApiHeaderEnum::PER_PAGE)
            ->assertHeader(1, RestApiHeaderEnum::TOTAL_COUNT)
            ->assertHeader(1, RestApiHeaderEnum::PAGE_COUNT)
            ->assertPath(2, '0.id')
            ->assertPath('Post 2', '0.title')
            ->assertPath('Content 2', '0.content');

        $response = $this->sendRequest('/v1/post?filter[titleBad]=qwerty');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'filter.titleBad',
                    'message' => 'Это поле не ожидалось.',
                ],
            ], 'errors');
    }

    /*public function testGetExpandedPostList()
    {
        $response = $this->sendRequest('/v1/post?page[size]=2&expand=comments,author');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertCollectionSize(2)
            ->assertHeader(1, RestApiHeaderEnum::CURRENT_PAGE)
            ->assertHeader(2, RestApiHeaderEnum::PER_PAGE)
            ->assertHeader(50, RestApiHeaderEnum::TOTAL_COUNT)
            ->assertHeader(25, RestApiHeaderEnum::PAGE_COUNT)
            ->assertPath(1, '0.id')
            ->assertPath('Post 1', '0.title')
            ->assertPath('Content 1', '0.content')
            ->assertPath(2, '1.id')
            ->assertPath('Post 2', '1.title')
            ->assertPath('Content 2', '1.content')
        ;

        $response = $this->sendRequest('/v1/post?page[size]=2&expand[]=comments&expand[]=author');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertCollectionSize(2)
            ->assertHeader(1, RestApiHeaderEnum::CURRENT_PAGE)
            ->assertHeader(2, RestApiHeaderEnum::PER_PAGE)
            ->assertHeader(50, RestApiHeaderEnum::TOTAL_COUNT)
            ->assertHeader(25, RestApiHeaderEnum::PAGE_COUNT)
            ->assertPath(1, '0.id')
            ->assertPath('Post 1', '0.title')
            ->assertPath('Content 1', '0.content')
            ->assertPath(2, '1.id')
            ->assertPath('Post 2', '1.title')
            ->assertPath('Content 2', '1.content')
        ;

        $response = $this->sendRequest('/v1/post?page[size]=2&expand[]=commentsBad&expand[]=author');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'expand',
                    'message' => 'Одно или несколько заданных значений недопустимо.',
                ],
            ], 'errors');
    }*/

    /**
     * @see php bin/phpunit --filter testGetListOfPage tests/RestApi/Blog/GetPostListTest.php
     */
    public function testGetListOfPage()
    {
        $response = $this->sendRequest('/v1/post?page[size]=2&page[number]=2');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertCollectionSize(2)
            ->assertHeader(2, RestApiHeaderEnum::CURRENT_PAGE)
            ->assertHeader(2, RestApiHeaderEnum::PER_PAGE)
            ->assertHeader(10, RestApiHeaderEnum::TOTAL_COUNT)
            ->assertHeader(5, RestApiHeaderEnum::PAGE_COUNT)
            ->assertPath(3, '0.id')
            ->assertPath(4, '1.id');

        $response = $this->sendRequest('/v1/post?page[size]=0&page[number]=0');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'page.number',
                    'message' => 'Значение должно быть положительным.',
                ],
                [
                    'field' => 'page.size',
                    'message' => 'Значение должно быть положительным.',
                ],
            ], 'errors');

        $response = $this->sendRequest('/v1/post?page[size]=30');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'page.size',
                    'message' => 'Значение должно быть меньше или равно 20.',
                ],
            ], 'errors');

        $response = $this->sendRequest('/v1/post?page[size]=2&page[number]=0');

        (new RestApiResponseAssert($response))
            ->assertStatus(422)
            ->assertPath([
                [
                    'field' => 'page.number',
                    'message' => 'Значение должно быть положительным.',
                ],
            ], 'errors');

        $response = $this->sendRequest('/v1/post?page[size]=2&page[number]=5');
        (new RestApiResponseAssert($response))
            ->assertStatus(200);

        $response = $this->sendRequest('/v1/post?page[size]=2&page[number]=6');

        (new RestApiResponseAssert($response))
            ->assertStatus(200)
            ->assertCollectionSize(0)
            ->assertData([]);
    }
}
